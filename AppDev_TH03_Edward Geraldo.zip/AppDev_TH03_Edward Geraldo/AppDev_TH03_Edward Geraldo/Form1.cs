﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev_TH03_Edward_Geraldo
{
    public partial class Form1 : Form
    {
        DataTable dtUCBank = new DataTable();
        int urut;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtUCBank.Columns.Add("Username");
            dtUCBank.Columns.Add("Password");
            dtUCBank.Columns.Add("Saldo");
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            panel_Awal.Visible = false;
            panel_RegisAkun.Visible = true;
          
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            bool cek = false;
            if (dtUCBank.Rows.Count == 0)
            {
                MessageBox.Show("Error");
            }
            for (int i = 0; i < dtUCBank.Rows.Count; i++)
            {
                if (dtUCBank.Rows[i][0].ToString() == tb_User.Text)
                {
                    urut = i;
                    cek = true;
                }
            }
            if (dtUCBank.Rows[urut][1].ToString() == tb_Pass.Text && cek == true)
            {
                MessageBox.Show("Login Succesful");
                tb_User.Text = ""; 
                tb_Pass.Text = "";
                int money = Convert.ToInt32(dtUCBank.Rows[urut][2]);
                lb_SALDO.Text = "Rp " + money.ToString("N");
                panel_Awal.Visible = false;
                panel_CekAkun.Visible = true;
                btn_LogOut.Visible = true;
            }
            else
            {
                MessageBox.Show("Wrong Password");
            }
        }

        private void btn_RegisUlang_Click(object sender, EventArgs e)
        {
            int counter = 0;
            for (int i = 0; i < dtUCBank.Rows.Count; i++)
            {
                if (dtUCBank.Rows[i][0].ToString() == tb_Username.Text)
                {
                    counter++;
                }
            }
            if (counter == 0)
            {
                dtUCBank.Rows.Add(tb_Username.Text, tb_Password.Text, "0");
                MessageBox.Show("Registration Succesful");
                tb_Username.Text = ""; tb_Password.Text = "";
                panel_RegisAkun.Visible = false;
                panel_Awal.Visible = true;
            }
            else if (counter >= 1)
            {
                MessageBox.Show("Username or Password is already taken");
            }
        }

        private void btn_Depo_Click(object sender, EventArgs e)
        {
            panel_CekAkun.Visible = false;
            panel_Deposit.Visible = true;
        }

        private void btn_Setor_Click(object sender, EventArgs e)
        {
            SetorUang(Convert.ToInt64(tb_InputDepo.Text));
            long uang = Convert.ToInt64(dtUCBank.Rows[urut][2]);
            lb_SALDO.Text = "Rp " + uang.ToString("N");
        }
        private void SetorUang(long uang)
        {
            long saldo = Convert.ToInt64(dtUCBank.Rows[urut][2]);
            if (uang > 0)
            {
                saldo = uang + saldo;
                dtUCBank.Rows[urut][2] = saldo;
                MessageBox.Show("Deposit Successful");
                tb_InputDepo.Text = "";
                panel_Deposit.Visible = false;
                panel_CekAkun.Visible = true;
            }
            else
            {
                MessageBox.Show("Deposit needs to be more than Rp. 0");
            }
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            panel_CekAkun.Visible = false;
            panel_Wdraw.Visible = true;
        }

        private void btn_Tarik_Click(object sender, EventArgs e)
        {
            panel_CekAkun.Visible = false;
            TarikUang(Convert.ToInt64(tb_InputWithdraw.Text));
            long uang = Convert.ToInt64(dtUCBank.Rows[urut][2]);
            lb_SALDO.Text = "Rp " + uang.ToString("N");
            panel_Wdraw.Visible = true;
        }
        private void TarikUang(long uang)
        {
            long saldo = Convert.ToInt64(dtUCBank.Rows[urut][2]);
            if (uang <= saldo)
            {
                saldo = saldo - uang;
                dtUCBank.Rows[urut][2] = saldo;
                MessageBox.Show("Withdraw Successful");
                tb_InputDepo.Text = "";
                panel_Wdraw.Visible = false;
                panel_CekAkun.Visible = true;
            }
            else if(uang > saldo)
            {
                MessageBox.Show("You don't have enough money to withdraw");
               
            }
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            panel_Awal.Visible = true;
            panel_CekAkun.Visible = false;
            panel_Deposit.Visible = false;
            panel_Wdraw.Visible = false;
            btn_LogOut.Visible = false;
        }
    }
}