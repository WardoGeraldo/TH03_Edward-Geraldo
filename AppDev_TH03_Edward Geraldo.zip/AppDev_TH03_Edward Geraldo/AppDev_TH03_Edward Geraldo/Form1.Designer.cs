﻿namespace AppDev_TH03_Edward_Geraldo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_UcBank = new System.Windows.Forms.Label();
            this.lb_Username = new System.Windows.Forms.Label();
            this.lb_Password = new System.Windows.Forms.Label();
            this.tb_User = new System.Windows.Forms.TextBox();
            this.tb_Pass = new System.Windows.Forms.TextBox();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_Register = new System.Windows.Forms.Button();
            this.panel_Awal = new System.Windows.Forms.Panel();
            this.panel_RegisAkun = new System.Windows.Forms.Panel();
            this.tb_Username = new System.Windows.Forms.TextBox();
            this.btn_RegisUlang = new System.Windows.Forms.Button();
            this.panel_CekAkun = new System.Windows.Forms.Panel();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.lb_SALDO = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.btn_Depo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_Password = new System.Windows.Forms.TextBox();
            this.panel_Deposit = new System.Windows.Forms.Panel();
            this.tb_InputDepo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_InputDepo = new System.Windows.Forms.Label();
            this.btn_Setor = new System.Windows.Forms.Button();
            this.panel_Wdraw = new System.Windows.Forms.Panel();
            this.tb_InputWithdraw = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lb_InputWithdraw = new System.Windows.Forms.Label();
            this.btn_Tarik = new System.Windows.Forms.Button();
            this.panel_Awal.SuspendLayout();
            this.panel_RegisAkun.SuspendLayout();
            this.panel_CekAkun.SuspendLayout();
            this.panel_Deposit.SuspendLayout();
            this.panel_Wdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_UcBank
            // 
            this.lb_UcBank.AutoSize = true;
            this.lb_UcBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UcBank.Location = new System.Drawing.Point(307, 68);
            this.lb_UcBank.Name = "lb_UcBank";
            this.lb_UcBank.Size = new System.Drawing.Size(150, 33);
            this.lb_UcBank.TabIndex = 0;
            this.lb_UcBank.Text = "UC BANK";
            // 
            // lb_Username
            // 
            this.lb_Username.AutoSize = true;
            this.lb_Username.Location = new System.Drawing.Point(21, 28);
            this.lb_Username.Name = "lb_Username";
            this.lb_Username.Size = new System.Drawing.Size(58, 13);
            this.lb_Username.TabIndex = 1;
            this.lb_Username.Text = "Username:";
            // 
            // lb_Password
            // 
            this.lb_Password.AutoSize = true;
            this.lb_Password.Location = new System.Drawing.Point(23, 75);
            this.lb_Password.Name = "lb_Password";
            this.lb_Password.Size = new System.Drawing.Size(56, 13);
            this.lb_Password.TabIndex = 2;
            this.lb_Password.Text = "Password:";
            // 
            // tb_User
            // 
            this.tb_User.Location = new System.Drawing.Point(85, 25);
            this.tb_User.Name = "tb_User";
            this.tb_User.Size = new System.Drawing.Size(100, 20);
            this.tb_User.TabIndex = 3;
            // 
            // tb_Pass
            // 
            this.tb_Pass.Location = new System.Drawing.Point(85, 72);
            this.tb_Pass.Name = "tb_Pass";
            this.tb_Pass.Size = new System.Drawing.Size(100, 20);
            this.tb_Pass.TabIndex = 4;
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(61, 115);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(75, 23);
            this.btn_Login.TabIndex = 5;
            this.btn_Login.Text = "LOGIN";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(61, 144);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(75, 23);
            this.btn_Register.TabIndex = 6;
            this.btn_Register.Text = "REGISTER";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // panel_Awal
            // 
            this.panel_Awal.Controls.Add(this.tb_User);
            this.panel_Awal.Controls.Add(this.btn_Register);
            this.panel_Awal.Controls.Add(this.lb_Username);
            this.panel_Awal.Controls.Add(this.btn_Login);
            this.panel_Awal.Controls.Add(this.lb_Password);
            this.panel_Awal.Controls.Add(this.tb_Pass);
            this.panel_Awal.Location = new System.Drawing.Point(287, 104);
            this.panel_Awal.Name = "panel_Awal";
            this.panel_Awal.Size = new System.Drawing.Size(200, 211);
            this.panel_Awal.TabIndex = 7;
            // 
            // panel_RegisAkun
            // 
            this.panel_RegisAkun.Controls.Add(this.tb_Username);
            this.panel_RegisAkun.Controls.Add(this.btn_RegisUlang);
            this.panel_RegisAkun.Controls.Add(this.label1);
            this.panel_RegisAkun.Controls.Add(this.label2);
            this.panel_RegisAkun.Controls.Add(this.tb_Password);
            this.panel_RegisAkun.Location = new System.Drawing.Point(287, 104);
            this.panel_RegisAkun.Name = "panel_RegisAkun";
            this.panel_RegisAkun.Size = new System.Drawing.Size(200, 211);
            this.panel_RegisAkun.TabIndex = 8;
            this.panel_RegisAkun.Visible = false;
            // 
            // tb_Username
            // 
            this.tb_Username.Location = new System.Drawing.Point(85, 25);
            this.tb_Username.Name = "tb_Username";
            this.tb_Username.Size = new System.Drawing.Size(100, 20);
            this.tb_Username.TabIndex = 3;
            // 
            // btn_RegisUlang
            // 
            this.btn_RegisUlang.Location = new System.Drawing.Point(64, 118);
            this.btn_RegisUlang.Name = "btn_RegisUlang";
            this.btn_RegisUlang.Size = new System.Drawing.Size(75, 23);
            this.btn_RegisUlang.TabIndex = 6;
            this.btn_RegisUlang.Text = "REGISTER";
            this.btn_RegisUlang.UseVisualStyleBackColor = true;
            this.btn_RegisUlang.Click += new System.EventHandler(this.btn_RegisUlang_Click);
            // 
            // panel_CekAkun
            // 
            this.panel_CekAkun.Controls.Add(this.btn_LogOut);
            this.panel_CekAkun.Controls.Add(this.lb_SALDO);
            this.panel_CekAkun.Controls.Add(this.lb_balance);
            this.panel_CekAkun.Controls.Add(this.btn_Withdraw);
            this.panel_CekAkun.Controls.Add(this.btn_Depo);
            this.panel_CekAkun.Location = new System.Drawing.Point(287, 104);
            this.panel_CekAkun.Name = "panel_CekAkun";
            this.panel_CekAkun.Size = new System.Drawing.Size(200, 211);
            this.panel_CekAkun.TabIndex = 8;
            this.panel_CekAkun.Visible = false;
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(61, 28);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(86, 23);
            this.btn_LogOut.TabIndex = 9;
            this.btn_LogOut.Text = "LOG OUT";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // lb_SALDO
            // 
            this.lb_SALDO.AutoSize = true;
            this.lb_SALDO.Location = new System.Drawing.Point(77, 72);
            this.lb_SALDO.Name = "lb_SALDO";
            this.lb_SALDO.Size = new System.Drawing.Size(10, 13);
            this.lb_SALDO.TabIndex = 8;
            this.lb_SALDO.Text = ".";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(22, 72);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(49, 13);
            this.lb_balance.TabIndex = 7;
            this.lb_balance.Text = "Balance:";
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(61, 144);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(86, 23);
            this.btn_Withdraw.TabIndex = 6;
            this.btn_Withdraw.Text = "WITHDRAW";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // btn_Depo
            // 
            this.btn_Depo.Location = new System.Drawing.Point(61, 115);
            this.btn_Depo.Name = "btn_Depo";
            this.btn_Depo.Size = new System.Drawing.Size(86, 23);
            this.btn_Depo.TabIndex = 5;
            this.btn_Depo.Text = "DEPOSIT";
            this.btn_Depo.UseVisualStyleBackColor = true;
            this.btn_Depo.Click += new System.EventHandler(this.btn_Depo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Username:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password:";
            // 
            // tb_Password
            // 
            this.tb_Password.Location = new System.Drawing.Point(85, 72);
            this.tb_Password.Name = "tb_Password";
            this.tb_Password.Size = new System.Drawing.Size(100, 20);
            this.tb_Password.TabIndex = 4;
            // 
            // panel_Deposit
            // 
            this.panel_Deposit.Controls.Add(this.tb_InputDepo);
            this.panel_Deposit.Controls.Add(this.label3);
            this.panel_Deposit.Controls.Add(this.lb_InputDepo);
            this.panel_Deposit.Controls.Add(this.btn_Setor);
            this.panel_Deposit.Location = new System.Drawing.Point(287, 104);
            this.panel_Deposit.Name = "panel_Deposit";
            this.panel_Deposit.Size = new System.Drawing.Size(200, 211);
            this.panel_Deposit.TabIndex = 10;
            this.panel_Deposit.Visible = false;
            // 
            // tb_InputDepo
            // 
            this.tb_InputDepo.Location = new System.Drawing.Point(52, 115);
            this.tb_InputDepo.Name = "tb_InputDepo";
            this.tb_InputDepo.Size = new System.Drawing.Size(109, 20);
            this.tb_InputDepo.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = ".";
            // 
            // lb_InputDepo
            // 
            this.lb_InputDepo.AutoSize = true;
            this.lb_InputDepo.Location = new System.Drawing.Point(49, 89);
            this.lb_InputDepo.Name = "lb_InputDepo";
            this.lb_InputDepo.Size = new System.Drawing.Size(112, 13);
            this.lb_InputDepo.TabIndex = 7;
            this.lb_InputDepo.Text = "Input Deposit Amount:";
            // 
            // btn_Setor
            // 
            this.btn_Setor.Location = new System.Drawing.Point(61, 155);
            this.btn_Setor.Name = "btn_Setor";
            this.btn_Setor.Size = new System.Drawing.Size(86, 23);
            this.btn_Setor.TabIndex = 5;
            this.btn_Setor.Text = "DEPOSIT";
            this.btn_Setor.UseVisualStyleBackColor = true;
            this.btn_Setor.Click += new System.EventHandler(this.btn_Setor_Click);
            // 
            // panel_Wdraw
            // 
            this.panel_Wdraw.Controls.Add(this.tb_InputWithdraw);
            this.panel_Wdraw.Controls.Add(this.label4);
            this.panel_Wdraw.Controls.Add(this.lb_InputWithdraw);
            this.panel_Wdraw.Controls.Add(this.btn_Tarik);
            this.panel_Wdraw.Location = new System.Drawing.Point(287, 104);
            this.panel_Wdraw.Name = "panel_Wdraw";
            this.panel_Wdraw.Size = new System.Drawing.Size(200, 211);
            this.panel_Wdraw.TabIndex = 11;
            this.panel_Wdraw.Visible = false;
            // 
            // tb_InputWithdraw
            // 
            this.tb_InputWithdraw.Location = new System.Drawing.Point(52, 115);
            this.tb_InputWithdraw.Name = "tb_InputWithdraw";
            this.tb_InputWithdraw.Size = new System.Drawing.Size(109, 20);
            this.tb_InputWithdraw.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(10, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = ".";
            // 
            // lb_InputWithdraw
            // 
            this.lb_InputWithdraw.AutoSize = true;
            this.lb_InputWithdraw.Location = new System.Drawing.Point(49, 89);
            this.lb_InputWithdraw.Name = "lb_InputWithdraw";
            this.lb_InputWithdraw.Size = new System.Drawing.Size(121, 13);
            this.lb_InputWithdraw.TabIndex = 7;
            this.lb_InputWithdraw.Text = "Input Withdraw Amount:";
            // 
            // btn_Tarik
            // 
            this.btn_Tarik.Location = new System.Drawing.Point(61, 155);
            this.btn_Tarik.Name = "btn_Tarik";
            this.btn_Tarik.Size = new System.Drawing.Size(86, 23);
            this.btn_Tarik.TabIndex = 5;
            this.btn_Tarik.Text = "WITHDRAW";
            this.btn_Tarik.UseVisualStyleBackColor = true;
            this.btn_Tarik.Click += new System.EventHandler(this.btn_Tarik_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel_Wdraw);
            this.Controls.Add(this.panel_Deposit);
            this.Controls.Add(this.panel_RegisAkun);
            this.Controls.Add(this.panel_CekAkun);
            this.Controls.Add(this.panel_Awal);
            this.Controls.Add(this.lb_UcBank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_Awal.ResumeLayout(false);
            this.panel_Awal.PerformLayout();
            this.panel_RegisAkun.ResumeLayout(false);
            this.panel_RegisAkun.PerformLayout();
            this.panel_CekAkun.ResumeLayout(false);
            this.panel_CekAkun.PerformLayout();
            this.panel_Deposit.ResumeLayout(false);
            this.panel_Deposit.PerformLayout();
            this.panel_Wdraw.ResumeLayout(false);
            this.panel_Wdraw.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_UcBank;
        private System.Windows.Forms.Label lb_Username;
        private System.Windows.Forms.Label lb_Password;
        private System.Windows.Forms.TextBox tb_User;
        private System.Windows.Forms.TextBox tb_Pass;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Panel panel_Awal;
        private System.Windows.Forms.Panel panel_RegisAkun;
        private System.Windows.Forms.TextBox tb_Username;
        private System.Windows.Forms.Button btn_RegisUlang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_Password;
        private System.Windows.Forms.Panel panel_CekAkun;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Button btn_Depo;
        private System.Windows.Forms.Label lb_SALDO;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Panel panel_Deposit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_InputDepo;
        private System.Windows.Forms.Button btn_Setor;
        private System.Windows.Forms.TextBox tb_InputDepo;
        private System.Windows.Forms.Panel panel_Wdraw;
        private System.Windows.Forms.TextBox tb_InputWithdraw;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_InputWithdraw;
        private System.Windows.Forms.Button btn_Tarik;
    }
}

